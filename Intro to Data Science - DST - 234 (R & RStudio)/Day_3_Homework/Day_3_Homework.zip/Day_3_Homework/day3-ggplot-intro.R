# DST 234 - loading up a ggplot gui

# NOTE: it is ok that we don't know everything on how this works (yet) - I just want to get you up and running

###### ONE TIME ONLY:
install.packages("tidyverse")
install.pacakges("ggplotgui")


###### ONCE THAT IS DONE, THEN:
ggplotgui::ggplot_shiny()
